from flask import Flask, request, jsonify
from datetime import datetime
import threading

app = Flask(__name__)
positions = {}  # project_name -> { user_id: {lat, lon, name, timestamp} }

@app.route('/update', methods=['POST'])
def update_position():
    data = request.json
    project = data.get('project')
    user_id = data.get('user_id')
    name = data.get('name')
    lat = data.get('lat')
    lon = data.get('lon')

    if not all([project, user_id, name, lat, lon]):
        return 'Missing data', 400

    if project not in positions:
        positions[project] = {}

    positions[project][user_id] = {
        'lat': lat,
        'lon': lon,
        'name': name,
        'timestamp': datetime.utcnow().isoformat()
    }
    return 'OK', 200

@app.route('/positions/<project>', methods=['GET'])
def get_positions(project):
    return jsonify(positions.get(project, {}))

# Optional: Cleanup old positions (no update for 30 seconds = remove)
def cleanup():
    import time
    while True:
        now = datetime.utcnow()
        for project in list(positions):
            for user in list(positions[project]):
                timestamp = datetime.fromisoformat(positions[project][user]['timestamp'])
                if (now - timestamp).total_seconds() > 30:
                    del positions[project][user]
        time.sleep(10)

threading.Thread(target=cleanup, daemon=True).start()

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
