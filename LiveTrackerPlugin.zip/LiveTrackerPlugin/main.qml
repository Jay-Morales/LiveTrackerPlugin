import QtQuick 2.12
import QtQuick.Controls 2.5
import QtLocation 5.12
import QtPositioning 5.12
import QtQuick.Layouts 1.12

Item {
    id: root
    property string projectName: project.fileName.split("/").pop().split(".")[0]
    property string serverUrl: "http://192.168.1.13:5000/get/" + projectName

    Timer {
        interval: 10000
        repeat: true
        running: true
        onTriggered: {
            fetchLocations()
        }
    }

    Map {
        id: map
        anchors.fill: parent
        plugin: Plugin { name: "osm" }
        center: QtPositioning.coordinate(10.123, 123.456)
        zoomLevel: 15
    }

    // Button with SVG icon
    Button {
        id: liveTrackerButton
        anchors.right: parent.right
        anchors.bottom: parent.bottom
        anchors.margins: 20
        width: 50
        height: 50
        background: Rectangle {
            color: "white"
            radius: 25
            border.color: "black"
            border.width: 2
        }
        
        contentItem: Image {
            source: "file:///E:/Jay Files Computer/Jay Files/TCWD_Works/QGIS FILES/QField/QFIELD-Plug-ins/LiveTrackerPlugin/icon.svg"
            width: 32
            height: 32
            fillMode: Image.PreserveAspectFit
        }

        onClicked: {
            console.log("LiveTracker button clicked!")
            fetchLocations()
        }
    }

    function fetchLocations() {
        var xhr = new XMLHttpRequest()
        xhr.open("GET", serverUrl)
        xhr.onreadystatechange = function() {
            if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
                var data = JSON.parse(xhr.responseText)
                map.children.forEach(function(child) {
                    if (child.objectName === "collabMarker") {
                        child.destroy()
                    }
                })
                for (var name in data) {
                    var coord = QtPositioning.coordinate(data[name].lat, data[name].lon)
                    var marker = Qt.createQmlObject('import QtQuick 2.12; import QtLocation 5.12; MapQuickItem { objectName: "collabMarker"; coordinate: QtPositioning.coordinate(0,0); anchorPoint.x: 12; anchorPoint.y: 24; sourceItem: Column { spacing: 2; Text { text: "' + name + '"; font.bold: true; color: "black"; } Rectangle { width: 12; height: 12; radius: 6; color: "blue" } } }', map)
                    marker.coordinate = coord
                    map.addMapItem(marker)
                }
            }
        }
        xhr.send()
    }
}
