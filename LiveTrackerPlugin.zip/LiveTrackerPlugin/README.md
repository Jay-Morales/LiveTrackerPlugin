
---

## ⚙️ How It Works

- Each QField device with the plugin **sends GPS data** every 10 seconds to your server.
- All users on the **same project** see each other's position.
- When switching projects in QField, only users working on that project will be shown.

---

## ✅ Installation Instructions

### 1. 📱 Install Plugin in QField

On your QField device:

- Open QField
- Go to **Settings → Plugins → Install from URL**
- Paste your GitHub raw URL to this folder, for example:


- The plugin will appear in the lower-right corner of the map.
- It sends your GPS location and shows all nearby collaborators (on the same project).

---

### 2. 💻 Set Up the Local Server (on Laptop or Desktop)

#### a. Install Python & Flask (only once):

If not yet installed:

```bash
pip install flask

## ✅ Running Server
cd server/
python server.py
##Find your local IP address, e.g.:
IPv4 Address: 192.168.1.13
⚠️ Make sure your phone and laptop are on the same Wi-Fi network.
